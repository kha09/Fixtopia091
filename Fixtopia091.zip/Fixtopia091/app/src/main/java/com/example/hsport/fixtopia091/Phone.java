package com.example.hsport.fixtopia091;

public class Phone {
    private String Iphone;

    public Phone() {
    }

    public Phone(String iphone) {
        Iphone = iphone;
    }

    public String getIphone() {
        return Iphone;
    }

    public void setIphone(String iphone) {
        Iphone = iphone;
    }
}

